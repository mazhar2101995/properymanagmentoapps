// Copyright (c) 2023, inceptionSystem and contributors
// For license information, please see license.txt

// frappe.ui.form.on("Property Oapps", {
// 	refresh(frm) {

// 	},
// });
